from . import sh_molli 

sh_molli.__main__()
